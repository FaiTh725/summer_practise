## Task description ##

Implement a [FindGcd](GcdTask/IntegerExtensions.cs#L15) method to find the [GCD](https://en.wikipedia.org/wiki/Greatest_common_divisor) of two integers. _The task definition is given in the XML-comments for the method._

*Topics - algorithms*.