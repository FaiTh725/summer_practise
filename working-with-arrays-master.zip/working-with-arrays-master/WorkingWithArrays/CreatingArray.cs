using System;

namespace WorkingWithArrays
{
    public static class CreatingArray
    {
        public static int[] CreateEmptyArrayOfIntegers()
        {
            int[] arr = Array.Empty<int>();
            return arr;
            throw new NotImplementedException();
        }

        public static bool[] CreateEmptyArrayOfBooleans()
        {
            bool[] arr = Array.Empty<bool>();
            return arr;

            throw new NotImplementedException();
        }

        public static string[] CreateEmptyArrayOfStrings()
        {
            string[] arr = Array.Empty<string>();
            return arr;

            throw new NotImplementedException();
        }

        public static char[] CreateEmptyArrayOfCharacters()
        {
            char[] arr = Array.Empty<char>();
            return arr;

            throw new NotImplementedException();
        }

        public static double[] CreateEmptyArrayOfDoubles()
        {
            double[] arr = Array.Empty<double>();
            return arr;

            throw new NotImplementedException();
        }

        public static float[] CreateEmptyArrayOfFloats()
        {
            float[] arr = Array.Empty<float>();
            return arr;

            throw new NotImplementedException();
        }

        public static decimal[] CreateEmptyArrayOfDecimals()
        {
            decimal[] arr = Array.Empty<decimal>();
            return arr;

            throw new NotImplementedException();
        }

        public static int[] CreateArrayOfTenIntegersWithDefaultValues()
        {
            int[] arr = new int[10];
            for (int i = 0; i < arr.Length; i++)
            {
                arr[i] = default;
            }

            return arr;

            throw new NotImplementedException();
        }

        public static bool[] CreateArrayOfTwentyBooleansWithDefaultValues()
        {
            bool[] arr = new bool[20];
            for (int i = 0; i < arr.Length; i++)
            {
                arr[i] = default;
            }

            return arr;
            throw new NotImplementedException();
        }

        public static string[] CreateArrayOfFiveEmptyStrings()
        {
            string[] arr = new string[5];
            for (int i = 0; i < arr.Length; i++)
            {
                arr[i] = default;
            }

            return arr;
            throw new NotImplementedException();
        }

        public static char[] CreateArrayOfFifteenCharactersWithDefaultValues()
        {
            char[] arr = new char[15];
            for (int i = 0; i < arr.Length; i++)
            {
                arr[i] = default;
            }

            return arr;
            throw new NotImplementedException();
        }

        public static double[] CreateArrayOfEighteenDoublesWithDefaultValues()
        {
            double[] arr = new double[18];
            for (int i = 0; i < arr.Length; i++)
            {
                arr[i] = default;
            }

            return arr;
            throw new NotImplementedException();
        }

        public static float[] CreateArrayOfOneHundredFloatsWithDefaultValues()
        {
            float[] arr = new float[100];
            for (int i = 0; i < arr.Length; i++)
            {
                arr[i] = default;
            }

            return arr;
            throw new NotImplementedException();
        }

        public static decimal[] CreateArrayOfOneThousandDecimalsWithDefaultValues()
        {
            decimal[] arr = new decimal[1000];
            for (int i = 0; i < arr.Length; i++)
            {
                arr[i] = default;
            }

            return arr;
            throw new NotImplementedException();
        }

        public static int[] CreateIntArrayWithOneElement()
        {
            int[] arr = { 123456 };
            return arr;

            throw new NotImplementedException();
        }

        public static int[] CreateIntArrayWithTwoElements()
        {
            int[] arr = { 1_111_111, 9_999_999 };
            return arr;

            throw new NotImplementedException();
        }

        public static int[] CreateIntArrayWithTenElements()
        {
            int[] arr = { 0, 4_234, 3_845, 2_942, 1_104, 9_794, 923_943, 7_537, 4_162, 10_134 };
            return arr;
            throw new NotImplementedException();
        }

        public static bool[] CreateBoolArrayWithOneElement()
        {
            bool[] arr = { true };
            return arr;

            throw new NotImplementedException();
        }

        public static bool[] CreateBoolArrayWithFiveElements()
        {
            bool[] arr = new bool[5];

            for (int i = 0; i < arr.Length; i++)
            {
                if (i % 2 == 1)
                {
                    arr[i] = false;
                }
                else
                {
                    arr[i] = true;
                }
            }

            return arr;
            throw new NotImplementedException();
        }

        public static bool[] CreateBoolArrayWithSevenElements()
        {
            bool[] arr = new bool[7];

            for (int i = 0; i < arr.Length; i++)
            {
                if (i % 3 == 0)
                {
                    arr[i] = false;
                }
                else
                {
                    arr[i] = true;
                }
            }

            return arr;

            throw new NotImplementedException();
        }

        public static string[] CreateStringArrayWithOneElement()
        {
            string[] arr = { "one" };
            return arr;

            throw new NotImplementedException();
        }

        public static string[] CreateStringArrayWithThreeElements()
        {
            string[] arr = { "one", "two", "three" };
            return arr;
            throw new NotImplementedException();
        }

        public static string[] CreateStringArrayWithSixElements()
        {
            var arr = new[]
            {
                "one", "two", "three", "four", "five", "six",
            };
            return arr;
            throw new NotImplementedException();
        }

        public static char[] CreateCharArrayWithOneElement()
        {
            char[] arr = { 'a' };
            return arr;

            throw new NotImplementedException();
        }

        public static char[] CreateCharArrayWithThreeElements()
        {
            char[] arr = { 'a', 'b', 'c' };
            return arr;

            throw new NotImplementedException();
        }

        public static char[] CreateCharArrayWithNineElements()
        {
            char[] arr = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'a' };
            return arr;
            throw new NotImplementedException();
        }

        public static double[] CreateDoubleArrayWithOneElement()
        {
            double[] arr = { 1.12 };
            return arr;
            throw new NotImplementedException();
        }

        public static double[] CreateDoubleWithFiveElements()
        {
            double[] arr = { 1.12, 2.23, 3.34, 4.45, 5.56 };
            return arr;
            throw new NotImplementedException();
        }

        public static double[] CreateDoubleWithNineElements()
        {
            double[] arr = { 1.12, 2.23, 3.34, 4.45, 5.56, 6.67, 7.78, 8.89, 9.91 };
            return arr;
            throw new NotImplementedException();
        }

        public static float[] CreateFloatArrayWithOneElement()
        {
            float[] arr = { 123456789.123456f };
            return arr;
            throw new NotImplementedException();
        }

        public static float[] CreateFloatWithThreeElements()
        {
            var arr = new[]
            {
                1_000_000.123456f, 2_223_334_444.123456f, 9_999.999999f,
            };
            return arr;

            throw new NotImplementedException();
        }

        public static float[] CreateFloatWithFiveElements()
        {
            float[] arr = { 1.01_23f, 20.01_23_45f, 300.01_23_45_67f, 4_000.0123_4567f, 50_0000.01234567f };
            return arr;
            throw new NotImplementedException();
        }

        public static decimal[] CreateDecimalArrayWithOneElement()
        {
            decimal[] arr = { 10_000.123456M };
            return arr;
            throw new NotImplementedException();
        }

        public static decimal[] CreateDecimalWithFiveElements()
        {
            decimal[] arr = { 1_000.1234m, 100_000.2345m, 100_000.3456m, 1_000_000.456789m, 10_000_000.5678901m };
            return arr;
            throw new NotImplementedException();
        }

        public static decimal[] CreateDecimalWithNineElements()
        {
            decimal[] arr = { 10.122112m, 200.233223m, 3_000.344334m, 40_000.455445m, 500_000.566556m, 6_000_000.677667m, 70_000_000.788778m, 800_000_000.899889m, 9_000_000_000.911991m };
            return arr;
            throw new NotImplementedException();
        }
    }
}
