using System;

namespace WorkingWithArrays
{
    public static class UsingRanges
    {
        public static int[] GetArrayWithAllElements(int[] array)
        {
            int[] result = new int[array.Length];
            array.CopyTo(result, 0);
            return result;
            throw new NotImplementedException();
        }

        public static int[] GetArrayWithoutFirstElement(int[] array)
        {
            int[] result = new int[array.Length - 1];
            Array.Copy(array, 1, result, 0, result.Length);
            return result;
            throw new NotImplementedException();
        }

        public static int[] GetArrayWithoutTwoFirstElements(int[] array)
        {
            int[] result = new int[array.Length - 2];
            Array.Copy(array, 2, result, 0, result.Length);
            return result;
            throw new NotImplementedException();
        }

        public static int[] GetArrayWithoutThreeFirstElements(int[] array)
        {
            int[] result = new int[array.Length - 3];
            Array.Copy(array, 3, result, 0, result.Length);
            return result;
            throw new NotImplementedException();
        }

        public static int[] GetArrayWithoutLastElement(int[] array)
        {
            int[] result = new int[array.Length - 1];
            Array.Copy(array, result, result.Length);
            return result;
            throw new NotImplementedException();
        }

        public static int[] GetArrayWithoutTwoLastElements(int[] array)
        {
            int[] result = new int[array.Length - 2];
            Array.Copy(array, result, result.Length);
            return result;
            throw new NotImplementedException();
        }

        public static int[] GetArrayWithoutThreeLastElements(int[] array)
        {
            int[] result = new int[array.Length - 3];
            Array.Copy(array, result, result.Length);
            return result;
            throw new NotImplementedException();
        }

        public static bool[] GetArrayWithoutFirstAndLastElements(bool[] array)
        {
            bool[] result = new bool[array.Length - 2];
            Array.Copy(array, 1, result, 0, result.Length);
            return result;
            throw new NotImplementedException();
        }

        public static bool[] GetArrayWithoutTwoFirstAndTwoLastElements(bool[] array)
        {
            bool[] result = new bool[array.Length - 4];
            Array.Copy(array, 2, result, 0, result.Length);
            return result;
            throw new NotImplementedException();
        }

        public static bool[] GetArrayWithoutThreeFirstAndThreeLastElements(bool[] array)
        {
            bool[] result = new bool[array.Length - 6];
            Array.Copy(array, 3, result, 0, result.Length);
            return result;
            throw new NotImplementedException();
        }
    }
}
