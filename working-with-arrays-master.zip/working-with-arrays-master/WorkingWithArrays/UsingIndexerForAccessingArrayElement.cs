using System;

namespace WorkingWithArrays
{
    public static class UsingIndexerForAccessingArrayElement
    {
        public static int GetFirstArrayElement(int[] array)
        {
            return array[0];
            throw new NotImplementedException();
        }

        public static int GetSecondArrayElement(int[] array)
        {
            return array[1];
            throw new NotImplementedException();
        }

        public static int GetThirdArrayElement(int[] array)
        {
            return array[2];
            throw new NotImplementedException();
        }

        public static int GetLastElement(int[] array)
        {
            return array[^1];
            throw new NotImplementedException();
        }

        public static int GetNextToLastElement(int[] array)
        {
            return array[^2];
            throw new NotImplementedException();
        }

        public static int GetNthArrayElement(int[] array, int n)
        {
            return array[n - 1];
            throw new NotImplementedException();
        }

        public static bool GetFirstArrayElement(bool[] array)
        {
            return array[0];
            throw new NotImplementedException();
        }

        public static bool GetSecondArrayElement(bool[] array)
        {
            return array[1];
            throw new NotImplementedException();
        }

        public static bool GetSixthArrayElement(bool[] array)
        {
            return array[5];
            throw new NotImplementedException();
        }

        public static bool GetLastElement(bool[] array)
        {
            return array[^1];
            throw new NotImplementedException();
        }

        public static bool GetNextToLastElement(bool[] array)
        {
            return array[^2];
            throw new NotImplementedException();
        }

        public static bool GetNthArrayElement(bool[] array, int n)
        {
            return array[n - 1];
            throw new NotImplementedException();
        }

        public static string GetFirstArrayElement(string[] array)
        {
            return array[0];
            throw new NotImplementedException();
        }

        public static string GetForthArrayElement(string[] array)
        {
            return array[3];
            throw new NotImplementedException();
        }

        public static string GetLastElement(string[] array)
        {
            return array[^1];
            throw new NotImplementedException();
        }

        public static string GetNextToLastElement(string[] array)
        {
            return array[^2];
            throw new NotImplementedException();
        }

        public static char GetFirstArrayElement(char[] array)
        {
            return array[0];
            throw new NotImplementedException();
        }

        public static char GetSeventhArrayElement(char[] array)
        {
            return array[6];
            throw new NotImplementedException();
        }

        public static char GetLastElement(char[] array)
        {
            return array[^1];
            throw new NotImplementedException();
        }

        public static char GetNextToLastElement(char[] array)
        {
            return array[^2];
            throw new NotImplementedException();
        }

        public static double GetFirstArrayElement(double[] array)
        {
            return array[0];
            throw new NotImplementedException();
        }

        public static double GetSeventhArrayElement(double[] array)
        {
            return array[6];
            throw new NotImplementedException();
        }

        public static double GetLastElement(double[] array)
        {
            return array[^1];
            throw new NotImplementedException();
        }

        public static double GetNextToLastElement(double[] array)
        {
            return array[^2];
            throw new NotImplementedException();
        }

        public static float GetFirstArrayElement(float[] array)
        {
            return array[0];
            throw new NotImplementedException();
        }

        public static float GetNinthArrayElement(float[] array)
        {
            return array[8];
            throw new NotImplementedException();
        }

        public static float GetLastElement(float[] array)
        {
            return array[^1];
            throw new NotImplementedException();
        }

        public static float GetNextToLastElement(float[] array)
        {
            return array[^2];
            throw new NotImplementedException();
        }

        public static decimal GetLastElement(decimal[] array)
        {
            return array[^1];
            throw new NotImplementedException();
        }

        public static decimal GetNextToLastElement(decimal[] array)
        {
            return array[^2];
            throw new NotImplementedException();
        }

        public static decimal GetThirdElementFromEnd(decimal[] array)
        {
            return array[^3];
            throw new NotImplementedException();
        }

        public static decimal GetFourthElementFromEnd(decimal[] array)
        {
            return array[^4];
            throw new NotImplementedException();
        }
    }
}
