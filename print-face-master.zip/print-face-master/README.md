## Task description

- C# program prints `"Hello, world!"` in a separate line. See [Program.Main](PrintFace/Program.cs#L10) method.     
- Implement a `SayHelloUser` method to print `"Hello, user name!"` in a separate line. See XML-comments for method [SayHelloUser](/PrintFace/Program.cs#L20).  
- Implement a `PrintFace` method to print this face.   
>         +"""""+ 
>        (| o o |)                                             
>         |  ^  |                                                 
>         | '-' |   
>         +-----+
*The task definition is given in the XML-comments for the [PrintFace](/PrintFace/Program.cs#L33) method.*