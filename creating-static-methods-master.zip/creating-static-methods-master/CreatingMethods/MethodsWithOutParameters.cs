using System.Runtime.CompilerServices;

namespace CreatingMethods
{
    public static class MethodsWithOutParameters
    {
        public static void ReturnValues(out bool trueValue, out bool falseValue)
        {
            trueValue = true;
            falseValue = false;
        }

        public static void ReturnValues(out char lowerCaseA, out char upperCaseA)
        {
            lowerCaseA = 'a';
            upperCaseA = 'A';
        }

        public static void ReturnValues(out float minFloatValues, out float maxFloatValues)
        {
            minFloatValues = float.MinValue;
            maxFloatValues = float.MaxValue;
        }

        public static void ReturnValues(out int minIntValues, out int intMaxIntValues)
        {
            minIntValues = int.MinValue;
            intMaxIntValues = int.MaxValue;
        }

        public static void ReturnValues(out long minLongValues, out long maxLongValues)
        {
            minLongValues = long.MinValue;
            maxLongValues = long.MaxValue;
        }
    }
}
