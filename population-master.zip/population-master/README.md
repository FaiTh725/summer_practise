## Task description ##

In a small town `initialPopulation` is the population at the beginning of a year. The population regularly increases by some `percents` per year and moreover `visitors` (new inhabitants per year) come to live in the town. How many years does the town need to see its population greater or equal to `currentPopulation` inhabitants? Implement this in [GetYears](PopulationTask/Population.cs#L25) method. *The task definition is given in the XML-comments for the method.*

*Topics - basic operation.*