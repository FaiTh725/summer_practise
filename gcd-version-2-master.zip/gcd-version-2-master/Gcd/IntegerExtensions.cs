using System;
using System.Linq;

namespace Gcd
{
    /// <summary>
    /// Provide methods with integers.
    /// </summary>
    public static class IntegerExtensions
    {
        /// <summary>
        /// Calculates GCD of two integers from [-int.MaxValue;int.MaxValue] by the Euclidean algorithm.
        /// </summary>
        /// <param name="a">First integer.</param>
        /// <param name="b">Second integer.</param>
        /// <returns>The GCD value.</returns>
        /// <exception cref="ArgumentException">Thrown when all numbers are 0 at the same time.</exception>
        /// <exception cref="ArgumentOutOfRangeException">Thrown when one or two numbers are int.MinValue.</exception>
        public static int GetGcdByEuclidean(int a, int b)
        {
            if (b == 0 && a == 0)
            {
                throw new ArgumentException("Two arg is null", nameof(a));
            }

            if (a == int.MinValue || b == int.MinValue)
            {
                throw new ArgumentOutOfRangeException(nameof(a), "one or two arg is minValue");
            }

            if (a == 0)
            {
                return Math.Abs(b);
            }

            if (b == 0)
            {
                return Math.Abs(a);
            }

            if (a < 0 || b < 0)
            {
                a = Math.Abs(a);
                b = Math.Abs(b);
            }

            // a-max
            if (a < b)
            {
                int temp = a;
                a = b;
                b = temp;
            }

            while (a != b)
            {
                a -= b;
                if (a < b)
                {
                    int temp = a;
                    a = b;
                    b = temp;
                }
            }

            return a;
        }

        /// <summary>
        /// Calculates GCD of three integers from [-int.MaxValue;int.MaxValue] by the Euclidean algorithm.
        /// </summary>
        /// <param name="a">First integer.</param>
        /// <param name="b">Second integer.</param>
        /// <param name="c">Third integer.</param>
        /// <returns>The GCD value.</returns>
        /// <exception cref="ArgumentException">Thrown when all numbers are 0 at the same time.</exception>
        /// <exception cref="ArgumentOutOfRangeException">Thrown when one or more numbers are int.MinValue.</exception>
        public static int GetGcdByEuclidean(int a, int b, int c)
        {
            if (a == 0 && b == 0 && c == 0)
            {
                throw new ArgumentException("Error", nameof(a));
            }

            if (a == 0 && b == 0)
            {
                return Math.Abs(c);
            }

            if (c == 0 && b == 0)
            {
                return Math.Abs(a);
            }

            if (a == 0 && c == 0)
            {
                return Math.Abs(b);
            }

            return GetGcdByEuclidean(GetGcdByEuclidean(a, b), c);
        }

        /// <summary>
        /// Calculates the GCD of integers from [-int.MaxValue;int.MaxValue] by the Euclidean algorithm.
        /// </summary>
        /// <param name="a">First integer.</param>
        /// <param name="b">Second integer.</param>
        /// <param name="other">Other integers.</param>
        /// <returns>The GCD value.</returns>
        /// <exception cref="ArgumentException">Thrown when all numbers are 0 at the same time.</exception>
        /// <exception cref="ArgumentOutOfRangeException">Thrown when one or more numbers are int.MinValue.</exception>
        public static int GetGcdByEuclidean(int a, int b, params int[] other)
        {
            if (a == 0 && b == 0 && other.All(n => n == 0))
            {
                throw new ArgumentException("Error", nameof(a));
            }

            if (a == int.MinValue || b == int.MinValue || other.Any(n => n == int.MinValue))
            {
                throw new ArgumentOutOfRangeException(nameof(b), "Error");
            }

            int gcd = a;

            foreach (int num in other)
            {
                if (num != 0)
                {
                    gcd = GetGcdByEuclidean(a, num);
                }
            }

            gcd = GetGcdByEuclidean(gcd, b);
            return gcd;
        }

        /// <summary>
        /// Calculates GCD of two integers [-int.MaxValue;int.MaxValue] by the Stein algorithm.
        /// </summary>
        /// <param name="a">First integer.</param>
        /// <param name="b">Second integer.</param>
        /// <returns>The GCD value.</returns>
        /// <exception cref="ArgumentException">Thrown when all numbers are 0 at the same time.</exception>
        /// <exception cref="ArgumentOutOfRangeException">Thrown when one or two numbers are int.MinValue.</exception>
        public static int GetGcdByStein(int a, int b)
        {
            if (a == 0 && b == 0)
            {
                throw new ArgumentException("Erorr", nameof(a));
            }

            if (a == int.MinValue || b == int.MinValue)
            {
                throw new ArgumentOutOfRangeException(nameof(b), "Error");
            }

            if (a == 0)
            {
                return Math.Abs(b);
            }

            if (b == 0)
            {
                return Math.Abs(a);
            }

            a = Math.Abs(a);
            b = Math.Abs(b);

            if ((a % 2 == 0) && (b % 2 == 0))
            {
                return GetGcdByStein(a / 2, b / 2) * 2;
            }

            if (a % 2 == 0)
            {
                return GetGcdByStein(a / 2, b);
            }

            if (b % 2 == 0)
            {
                return GetGcdByStein(a, b / 2);
            }

            if (a >= b)
            {
                return GetGcdByStein((a - b) / 2, b);
            }

            return GetGcdByStein(a, (b - a) / 2);
        }

        /// <summary>
        /// Calculates GCD of three integers [-int.MaxValue;int.MaxValue] by the Stein algorithm.
        /// </summary>
        /// <param name="a">First integer.</param>
        /// <param name="b">Second integer.</param>
        /// <param name="c">Third integer.</param>
        /// <returns>The GCD value.</returns>
        /// <exception cref="ArgumentException">Thrown when all numbers are 0 at the same time.</exception>
        /// <exception cref="ArgumentOutOfRangeException">Thrown when one or more numbers are int.MinValue.</exception>
        public static int GetGcdByStein(int a, int b, int c)
        {
            if (a == 0 && b == 0 && c == 0)
            {
                throw new ArgumentException("gert", nameof(a));
            }

            if (a == 0 && b == 0)
            {
                return Math.Abs(c);
            }

            if (c == 0 && b == 0)
            {
                return Math.Abs(a);
            }

            if (a == 0 && c == 0)
            {
                return Math.Abs(b);
            }

            return GetGcdByStein(GetGcdByStein(a, b), c);
        }

        /// <summary>
        /// Calculates the GCD of integers [-int.MaxValue;int.MaxValue] by the Stein algorithm.
        /// </summary>
        /// <param name="a">First integer.</param>
        /// <param name="b">Second integer.</param>
        /// <param name="other">Other integers.</param>
        /// <returns>The GCD value.</returns>
        /// <exception cref="ArgumentException">Thrown when all numbers are 0 at the same time.</exception>
        /// <exception cref="ArgumentOutOfRangeException">Thrown when one or more numbers are int.MinValue.</exception>
        public static int GetGcdByStein(int a, int b, params int[] other)
        {
            if (a == 0 && b == 0 && other.All(n => n == 0))
            {
                throw new ArgumentException("All numbers are 0 at the same time.", nameof(a));
            }

            if (a == int.MinValue || b == int.MinValue || other.Any(n => n == int.MinValue))
            {
                throw new ArgumentOutOfRangeException(nameof(b), "One or more numbers are int.MinValue.");
            }

            int gcd = a;

            foreach (int num in other)
            {
                if (num != 0)
                {
                    gcd = GetGcdByStein(a, num);
                }
            }

            gcd = GetGcdByStein(gcd, b);
            return gcd;
        }

        /// <summary>
        /// Calculates GCD of two integers from [-int.MaxValue;int.MaxValue] by the Euclidean algorithm with elapsed time.
        /// </summary>
        /// <param name="elapsedTicks">Method execution time in ticks.</param>
        /// <param name="a">First integer.</param>
        /// <param name="b">Second integer.</param>
        /// <returns>The GCD value.</returns>
        /// <exception cref="ArgumentException">Thrown when all numbers are 0 at the same time.</exception>
        /// <exception cref="ArgumentOutOfRangeException">Thrown when one or two numbers are int.MinValue.</exception>
        public static int GetGcdByEuclidean(out long elapsedTicks, int a, int b)
        {
            try
            {
                GetGcdByEuclidean(a, b);
            }
            catch (ArgumentOutOfRangeException)
            {
                Console.WriteLine("Error");
            }
            catch (ArgumentException)
            {
                Console.WriteLine("Error");
            }

            int gcd = GetGcdByEuclidean(a, b);
            elapsedTicks = DateTime.Now.Ticks;
            return gcd;
        }

        /// <summary>
        /// Calculates GCD of three integers from [-int.MaxValue;int.MaxValue] by the Euclidean algorithm with elapsed time.
        /// </summary>
        /// <param name="elapsedTicks">Method execution time in ticks.</param>
        /// <param name="a">First integer.</param>
        /// <param name="b">Second integer.</param>
        /// <param name="c">Third integer.</param>
        /// <returns>The GCD value.</returns>
        /// <exception cref="ArgumentException">Thrown when all numbers are 0 at the same time.</exception>
        /// <exception cref="ArgumentOutOfRangeException">Thrown when one or more numbers are int.MinValue.</exception>
        public static int GetGcdByEuclidean(out long elapsedTicks, int a, int b, int c)
        {
            try
            {
                GetGcdByEuclidean(a, b, c);
            }
            catch (ArgumentOutOfRangeException)
            {
                Console.WriteLine("Error");
            }
            catch (ArgumentException)
            {
                Console.WriteLine("Error");
            }

            int gcd = GetGcdByEuclidean(a, b, c);
            elapsedTicks = DateTime.Now.Ticks;
            return gcd;
        }

        /// <summary>
        /// Calculates the GCD of integers from [-int.MaxValue;int.MaxValue] by the Euclidean algorithm with elapsed time.
        /// </summary>
        /// <param name="elapsedTicks">Method execution time in Ticks.</param>
        /// <param name="a">First integer.</param>
        /// <param name="b">Second integer.</param>
        /// <param name="other">Other integers.</param>
        /// <returns>The GCD value.</returns>
        /// <exception cref="ArgumentException">Thrown when all numbers are 0 at the same time.</exception>
        /// <exception cref="ArgumentOutOfRangeException">Thrown when one or more numbers are int.MinValue.</exception>
        public static int GetGcdByEuclidean(out long elapsedTicks, int a, int b, params int[] other)
        {           
            try
            {
                GetGcdByEuclidean(a, b, other);
            }
            catch (ArgumentOutOfRangeException)
            {
                Console.WriteLine("Error");
            }
            catch (ArgumentException)
            {
                Console.WriteLine("Error");
            }

            int gcd = GetGcdByEuclidean(a, b, other);
            elapsedTicks = DateTime.Now.Ticks;
            return gcd;
        }

        /// <summary>
        /// Calculates GCD of two integers from [-int.MaxValue;int.MaxValue] by the Stein algorithm with elapsed time.
        /// </summary>
        /// <param name="elapsedTicks">Method execution time in ticks.</param>
        /// <param name="a">First integer.</param>
        /// <param name="b">Second integer.</param>
        /// <returns>The GCD value.</returns>
        /// <exception cref="ArgumentException">Thrown when all numbers are 0 at the same time.</exception>
        /// <exception cref="ArgumentOutOfRangeException">Thrown when one or two numbers are int.MinValue.</exception>
        public static int GetGcdByStein(out long elapsedTicks, int a, int b)
        {
            try
            {
                GetGcdByStein(a, b);
            }
            catch (ArgumentOutOfRangeException)
            {
                Console.WriteLine("Error");
            }
            catch (ArgumentException)
            {
                Console.WriteLine("Error");
            }

            int gcd = GetGcdByStein(a, b);
            elapsedTicks = DateTime.Now.Ticks;
            return gcd;
        }

        /// <summary>
        /// Calculates GCD of three integers from [-int.MaxValue;int.MaxValue] by the Stein algorithm with elapsed time.
        /// </summary>
        /// <param name="elapsedTicks">Method execution time in ticks.</param>
        /// <param name="a">First integer.</param>
        /// <param name="b">Second integer.</param>
        /// <param name="c">Third integer.</param>
        /// <returns>The GCD value.</returns>
        /// <exception cref="ArgumentException">Thrown when all numbers are 0 at the same time.</exception>
        /// <exception cref="ArgumentOutOfRangeException">Thrown when one or more numbers are int.MinValue.</exception>
        public static int GetGcdByStein(out long elapsedTicks, int a, int b, int c)
        {
            try
            {
                GetGcdByStein(a, b, c);
            }
            catch (ArgumentOutOfRangeException)
            {
                Console.WriteLine("Error");
            }
            catch (ArgumentException)
            {
                Console.WriteLine("Error");
            }

            int gcd = GetGcdByStein(a, b, c);
            elapsedTicks = DateTime.Now.Ticks;
            return gcd;
            throw new NotImplementedException("You need to implement this function.");
        }

        /// <summary>
        /// Calculates the GCD of integers from [-int.MaxValue;int.MaxValue] by the Stein algorithm with elapsed time.
        /// </summary>
        /// <param name="elapsedTicks">Method execution time in Ticks.</param>
        /// <param name="a">First integer.</param>
        /// <param name="b">Second integer.</param>
        /// <param name="other">Other integers.</param>
        /// <returns>The GCD value.</returns>
        /// <exception cref="ArgumentException">Thrown when all numbers are 0 at the same time.</exception>
        /// <exception cref="ArgumentOutOfRangeException">Thrown when one or more numbers are int.MinValue.</exception>
        public static int GetGcdByStein(out long elapsedTicks, int a, int b, params int[] other)
        {
            try
            {
                GetGcdByStein(a, b, other);
            }
            catch (ArgumentOutOfRangeException)
            {
                Console.WriteLine("Error");
            }
            catch (ArgumentException)
            {
                Console.WriteLine("Error");
            }         

            int gcd = GetGcdByStein(a, b, other);
            elapsedTicks = DateTime.Now.Ticks;
            return gcd;
        }
    }
}
