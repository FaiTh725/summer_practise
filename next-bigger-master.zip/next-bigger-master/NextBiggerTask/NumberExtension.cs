using System;
using System.Collections.Generic;
using System.Linq;

namespace NextBiggerTask
{
    public static class NumberExtension
    {
        /// <summary>
        /// Finds the nearest largest integer consisting of the digits of the given positive integer number and null if no such number exists.
        /// </summary>
        /// <param name="number">Source number.</param>
        /// <returns>
        /// The nearest largest integer consisting of the digits  of the given positive integer and null if no such number exists.
        /// </returns>
        /// <exception cref="ArgumentException">Thrown when source number is less than 0.</exception>

        public static int? NextBiggerThan(int number)
        {
            if (number < 0)
            {
                throw new ArgumentException();
            }

            // Convert the number to a list of digits
            List<int> digits = number.ToString().Select(c => int.Parse(c.ToString())).ToList();

            // Find the first index where the digit is in descending order
            int index = -1;
            for (int i = digits.Count - 1; i > 0; i--)
            {
                if (digits[i] > digits[i - 1])
                {
                    index = i - 1;
                    break;
                }
            }

            // If no such index is found, return null
            if (index == -1)
            {
                return null;
            }

            // Find the smallest digit greater than the digit at index
            int smallestLargerDigit = digits[index + 1];
            int smallestLargerIndex = index + 1;
            for (int i = index + 2; i < digits.Count; i++)
            {
                if (digits[i] > digits[index] && digits[i] < smallestLargerDigit)
                {
                    smallestLargerDigit = digits[i];
                    smallestLargerIndex = i;
                }
            }

            // Swap the smallest larger digit with the digit at index
            int temp = digits[index];
            digits[index] = digits[smallestLargerIndex];
            digits[smallestLargerIndex] = temp;

            // Sort the digits after index in ascending order
            List<int> sortedDigits = digits.GetRange(index + 1, digits.Count - index - 1);
            sortedDigits.Sort();

            // Combine the digits to form the nearest largest integer
            List<int> resultDigits = digits.GetRange(0, index + 1);
            resultDigits.AddRange(sortedDigits);

            int result = int.Parse(string.Join("", resultDigits));

            return result;
        }
    }
}
