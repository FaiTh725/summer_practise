using System;
using System.Linq;

namespace ShuffleCharacters
{
    public static class StringExtension
    {
        /// <summary>
        /// Shuffles characters in source string according some rule.
        /// </summary>
        /// <param name="source">The source string.</param>
        /// <param name="count">The count of iterations.</param>
        /// <returns>Result string.</returns>
        /// <exception cref="ArgumentException">Source string is null or empty or white spaces.</exception>
        /// <exception cref="ArgumentException">Count of iterations is less than 0.</exception>
        public static string ShuffleChars(string source, int count)
        {
            if (string.IsNullOrEmpty(source) || count < 0)
            {
                throw new ArgumentException("tryertyr", nameof(source));
            }

            if (string.IsNullOrWhiteSpace(source))
            {
                throw new ArgumentException("greter", nameof(source));
            }

            char[] result = source.ToCharArray();
            char[] array = new char[source.Length];
            char[] start = result.ToArray();
            var t = 0;
            int middle = (source.Length / 2) + (source.Length % 2);
            for (int k = 0; k < count; k++)
            {
                (array, result) = (result, array);

                for (int i = 0; i < middle; i++)
                {
                    result[i] = array[i * 2];
                }

                for (int i = middle, ii = 1; i < source.Length; i++, ii += 2)
                {
                    result[i] = array[ii];
                }

                t++;
                if (result.SequenceEqual(start))
                {
                    while (count > k + t)
                    {
                        count -= t;
                    }
                }
            }

            return new string(result);
        }
    }
}
