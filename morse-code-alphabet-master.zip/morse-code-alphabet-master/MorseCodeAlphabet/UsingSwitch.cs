namespace MorseCodeAlphabet
{
    public static class UsingSwitch
    {
        public static byte GetMorseCode(char c)
        {
            switch (c.ToString().ToUpper())
            {
                case "A":
                    return 0b0011_0001;

                case "B":
                    return 0b1111_1110;

                case "C":
                    return 0b1111_1010;

                case "D":
                    return 0b0111_0110;

                case "E":
                    return 0b0001_0001;

                case "F":
                    return 0b1111_1011;

                case "G":
                    return 0b0111_0100;

                case "H":
                    return 0b1111_1111;

                case "I":
                    return 0b0011_0011;

                case "J":
                    return 0b1111_0001;

                case "K":
                    return 0b0111_0010;

                case "L":
                    return 0b1111_1101;

                case "M":
                    return 0b0011_0000;

                case "N":
                    return 0b0011_0010;

                case "O":
                    return 0b0111_0000;

                case "P":
                    return 0b1111_1001;

                case "Q":
                    return 0b1111_0100;

                case "R":
                    return 0b0111_0101;

                case "S":
                    return 0b0111_0111;

                case "T":
                    return 0b0001_0000;

                case "U":
                    return 0b0111_0011;

                case "V":
                    return 0b1111_0111;

                case "W":
                    return 0b0111_0001;

                case "X":
                    return 0b1111_0110;

                case "Y":
                    return 0b1111_0010;

                case "Z":
                    return 0b1111_1100;

                default:
                    return 0b0000_0000;
            }
        }
    }
}
