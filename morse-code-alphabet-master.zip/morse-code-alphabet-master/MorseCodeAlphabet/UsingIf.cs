#pragma warning disable S3776

using System.Globalization;

namespace MorseCodeAlphabet
{
    public static class UsingIf
    {
        public static string GetMorseCode(char c)
        {
            if (c.ToString().ToUpper() == "A")
            {
                return ".-";
            }
            else if (c.ToString().ToUpper() == "B")
            {
                return "-...";
            }
            else if (c.ToString().ToUpper() == "C")
            {
                return "-.-.";
            }
            else if (c.ToString().ToUpper() == "D")
            {
                return "-..";
            }
            else if (c.ToString().ToUpper() == "E")
            {
                return ".";
            }
            else if (c.ToString().ToUpper() == "F")
            {
                return "..-.";
            }
            else if (c.ToString().ToUpper() == "G")
            {
                return "--.";
            }
            else if (c.ToString().ToUpper() == "H")
            {
                return "....";
            }
            else if (c.ToString().ToUpper() == "I")
            {
                return "..";
            }
            else if (c.ToString().ToUpper() == "J")
            {
                return ".---";
            }
            else if (c.ToString().ToUpper() == "K")
            {
                return "-.-";
            }
            else if (c.ToString().ToUpper() == "L")
            {
                return ".-..";
            }
            else if (c.ToString().ToUpper() == "M")
            {
                return "--";
            }
            else if (c.ToString().ToUpper() == "N")
            {
                return "-.";
            }
            else if (c.ToString().ToUpper() == "O")
            {
                return "---";
            }
            else if (c.ToString().ToUpper() == "P")
            {
                return ".--.";
            }
            else if (c.ToString().ToUpper() == "Q")
            {
                return "--.-";
            }
            else if (c.ToString().ToUpper() == "R")
            {
                return ".-.";
            }
            else if (c.ToString().ToUpper() == "S")
            {
                return "...";
            }
            else if (c.ToString().ToUpper() == "T")
            {
                return "-";
            }
            else if (c.ToString().ToUpper() == "U")
            {
                return "..-";
            }
            else if (c.ToString().ToUpper() == "V")
            {
                return "...-";
            }
            else if (c.ToString().ToUpper() == "W")
            {
                return ".--";
            }
            else if (c.ToString().ToUpper() == "X")
            {
                return "-..-";
            }
            else if (c.ToString().ToUpper() == "Y")
            {
                return "-.--";
            }
            else if (c.ToString().ToUpper() == "Z")
            {
                return "--..";
            }

            return string.Empty;
        }
    }
}
