## Task Description ##

Implement the [GetCountOfVowel](VowelCountTask/StringHelper.cs#L14) method to calculate the count of vowels in the given string. We will consider `a`, `e`, `i`, `o`, and `u` as vowels for this task. The input string will only consist of lower case letters and/or spaces. The task definition is given in the XML-comments for the method. _Do not use regular expression._

*Topics - chars, strings.*