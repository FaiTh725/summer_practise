﻿namespace ShiftArrayElements
{
    public enum Direction
    {
        Left,
        Right,
    }
}
