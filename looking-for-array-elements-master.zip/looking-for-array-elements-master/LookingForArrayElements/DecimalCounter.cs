using System;

#pragma warning disable S2368

namespace LookingForArrayElements
{
    public static class DecimalCounter
    {
        /// <summary>
        /// Searches an array of decimals for elements that are in a specified range, and returns the number of occurrences of the elements that matches the range criteria.
        /// </summary>
        /// <param name="arrayToSearch">One-dimensional, zero-based <see cref="Array"/> of single-precision floating-point numbers.</param>
        /// <param name="ranges">One-dimensional, zero-based <see cref="Array"/> of range arrays.</param>
        /// <returns>The number of occurrences of the <see cref="Array"/> elements that match the range criteria.</returns>
        public static int GetDecimalsCount(decimal[] arrayToSearch, decimal[][] ranges)
        {
            if (arrayToSearch == null || ranges == null)
            {
                throw new ArgumentNullException(nameof(arrayToSearch));
            }

            int count = 0;
            for (int i = 0; i < ranges.Length; i++)
            {
                if (ranges[i] == null)
                {
                    throw new ArgumentNullException(nameof(ranges));
                }

                for (int k = 0; k < ranges[i].Length - 1; k++)
                {
                    if (ranges[i][k] == decimal.Zero)
                    {
                        ranges[i][k] = 0;
                    }

                    if (ranges[i][k] == decimal.One)
                    {
                        ranges[i][k] = 0.1m;
                    }

                    if (ranges[i][k + 1] == decimal.Zero)
                    {
                        ranges[i][k + 1] = 0;
                    }

                    if (ranges[i][k + 1] == decimal.One)
                    {
                        ranges[i][k + 1] = 0.1m;
                    }

                    for (int j = 0; j < arrayToSearch.Length; j++)
                    {
                        if (arrayToSearch[j] >= ranges[i][k] && arrayToSearch[j] <= ranges[i][k + 1])
                        {
                            count++;
                        }
                    }
                }
            }

            return count;
        }

        /// <summary>
        /// Searches an array of decimals for elements that are in a specified range, and returns the number of occurrences of the elements that matches the range criteria.
        /// </summary>
        /// <param name="arrayToSearch">One-dimensional, zero-based <see cref="Array"/> of single-precision floating-point numbers.</param>
        /// <param name="ranges">One-dimensional, zero-based <see cref="Array"/> of range arrays.</param>
        /// <param name="startIndex">The zero-based starting index of the search.</param>
        /// <param name="count">The number of elements in the section to search.</param>
        /// <returns>The number of occurrences of the <see cref="Array"/> elements that match the range criteria.</returns>
        public static int GetDecimalsCount(decimal[] arrayToSearch, decimal[][] ranges, int startIndex, int count)
        {
            if (arrayToSearch == null || ranges == null)
            {
                throw new ArgumentNullException(nameof(arrayToSearch));
            }

            for (int i = 0; i < ranges.Length; i++)
            {
                if (ranges[i] == null)
                {
                    throw new ArgumentNullException(nameof(ranges));
                }
            }

            return GetDecimalsCount(arrayToSearch[startIndex.. (startIndex + count)], ranges);
            throw new NotImplementedException();
        }
    }
}
