## Task Description

Implement [IsLeapYear](LeapYearTask/Year.cs#L12) method that defines for given year if it is a leap year. *The task detail definitions are given in the  XML-comments for the method.*