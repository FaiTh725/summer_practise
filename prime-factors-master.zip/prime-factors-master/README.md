## Task description ##

Implement the [GetFactorsGiven](PrimeFactorsTask/PrimeFactors.cs#L22) which calculates the [prime](https://en.wikipedia.org/wiki/Prime_number) factors of a given natural number.    

*Tags - loops, integer operations.*